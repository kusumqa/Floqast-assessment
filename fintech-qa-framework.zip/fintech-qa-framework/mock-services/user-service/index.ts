/**
 * User Service (mock)
 * Node.js/Express + in-memory store standing in for MongoDB.
 * Owns user records. Trusts the API Gateway to have handled authentication;
 * focuses purely on business logic and validation, as a real internal
 * microservice would behind a gateway.
 */
import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { getConfig } from '../../config/environments';
import { ApiErrors } from '../shared/errors';
import { requestLoggingMiddleware } from '../shared/requestLogging';
import { PublicUser, User } from '../shared/types';

const app = express();
app.use(express.json());
app.use(requestLoggingMiddleware('user-service'));

const users = new Map<string, User>();
const emailIndex = new Map<string, string>(); // email (lowercased) -> userId
const tokenIndex = new Map<string, string>(); // apiToken -> userId

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ALLOWED_ACCOUNT_TYPES = ['basic', 'premium'];

function toPublic(user: User): PublicUser {
  const { apiToken, ...rest } = user;
  return rest;
}

app.post('/users', (req, res) => {
  const { name, email, accountType } = req.body ?? {};
  const details: Record<string, string> = {};

  if (typeof name !== 'string' || name.trim().length < 2) {
    details.name = 'name is required and must be at least 2 characters';
  }
  if (typeof email !== 'string' || !EMAIL_RE.test(email)) {
    details.email = 'email is required and must be a valid email address';
  }
  if (accountType !== undefined && !ALLOWED_ACCOUNT_TYPES.includes(accountType)) {
    details.accountType = `accountType must be one of: ${ALLOWED_ACCOUNT_TYPES.join(', ')}`;
  }
  if (Object.keys(details).length > 0) {
    return ApiErrors.validation(res, 'User creation failed validation', details);
  }

  const normalizedEmail = (email as string).toLowerCase();
  if (emailIndex.has(normalizedEmail)) {
    return ApiErrors.conflict(res, `A user with email "${email}" already exists`);
  }

  const user: User = {
    id: uuidv4(),
    name: (name as string).trim(),
    email: normalizedEmail,
    accountType: (accountType as User['accountType']) ?? 'basic',
    createdAt: new Date().toISOString(),
    apiToken: `usr_${uuidv4().replace(/-/g, '')}`,
  };

  users.set(user.id, user);
  emailIndex.set(normalizedEmail, user.id);
  tokenIndex.set(user.apiToken, user.id);

  // On creation only, return the apiToken so the "client" can authenticate later calls.
  return res.status(201).json({ ...toPublic(user), apiToken: user.apiToken });
});

app.get('/users/:id', (req, res) => {
  const user = users.get(req.params.id);
  if (!user) {
    return ApiErrors.notFound(res, `No user found with id "${req.params.id}"`);
  }
  return res.status(200).json(toPublic(user));
});

// Internal-only lookup used by the gateway to resolve an apiToken to a userId for auth.
app.get('/internal/tokens/:token', (req, res) => {
  const userId = tokenIndex.get(req.params.token);
  if (!userId) {
    return ApiErrors.notFound(res, 'Unknown token');
  }
  return res.status(200).json({ userId });
});

// Internal-only existence check used by transaction-service to validate userId/recipientId.
app.get('/internal/users/:id/exists', (req, res) => {
  return res.status(200).json({ exists: users.has(req.params.id) });
});

app.get('/health', (_req, res) => res.status(200).json({ status: 'ok', service: 'user-service' }));

const config = getConfig();
app.listen(config.userServicePort, () => {
  console.log(`[user-service] listening on port ${config.userServicePort} (env=${config.name})`);
});

export default app;
