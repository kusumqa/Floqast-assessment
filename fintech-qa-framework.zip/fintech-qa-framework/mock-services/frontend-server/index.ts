/**
 * Static file server for the mock frontend, plus a dynamically generated
 * /config.js so the frontend JS knows which Gateway URL to call for the
 * currently selected TEST_ENV - without hardcoding it into the HTML/JS.
 */
import express from 'express';
import path from 'path';
import { getConfig } from '../../config/environments';

const app = express();
const config = getConfig();

app.get('/config.js', (_req, res) => {
  res.type('application/javascript');
  res.send(`window.APP_CONFIG = ${JSON.stringify({ gatewayBaseUrl: config.gatewayBaseUrl, env: config.name })};`);
});

app.use(express.static(path.resolve(__dirname, '..', '..', 'mock-frontend')));

app.listen(config.frontendPort, () => {
  console.log(`[frontend-server] listening on port ${config.frontendPort} (env=${config.name})`);
});

export default app;
