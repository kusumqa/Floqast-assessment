/**
 * Notification Service (mock)
 * Node.js/Express + in-memory queue standing in for Redis.
 * Receives fire-and-forget notification requests (from Transaction Service)
 * and exposes a read endpoint so tests can assert a notification was queued.
 */
import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { getConfig } from '../../config/environments';
import { ApiErrors } from '../shared/errors';
import { requestLoggingMiddleware } from '../shared/requestLogging';
import { Notification } from '../shared/types';

const app = express();
app.use(express.json());
app.use(requestLoggingMiddleware('notification-service'));

const notificationsByUser = new Map<string, Notification[]>();

app.post('/notifications', (req, res) => {
  const { userId, channel, message } = req.body ?? {};
  if (typeof userId !== 'string' || typeof message !== 'string' || !['email', 'sms'].includes(channel)) {
    return ApiErrors.badRequest(res, 'userId, channel (email|sms) and message are required');
  }
  const notification: Notification = { id: uuidv4(), userId, channel, message, createdAt: new Date().toISOString() };
  const existing = notificationsByUser.get(userId) ?? [];
  existing.push(notification);
  notificationsByUser.set(userId, existing);
  return res.status(201).json(notification);
});

app.get('/notifications/:userId', (req, res) => {
  return res.status(200).json(notificationsByUser.get(req.params.userId) ?? []);
});

app.get('/health', (_req, res) => res.status(200).json({ status: 'ok', service: 'notification-service' }));

const config = getConfig();
app.listen(config.notificationServicePort, () => {
  console.log(`[notification-service] listening on port ${config.notificationServicePort} (env=${config.name})`);
});

export default app;
