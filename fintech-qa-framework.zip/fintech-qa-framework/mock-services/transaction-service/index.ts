/**
 * Transaction Service (mock)
 * Node.js/Express + in-memory store standing in for MongoDB.
 * Validates and records transactions, calling out to User Service (existence
 * checks) and Notification Service (fire-and-forget confirmation) the way a
 * real microservice would call its peers.
 */
import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { getConfig } from '../../config/environments';
import { ApiErrors } from '../shared/errors';
import { requestLoggingMiddleware } from '../shared/requestLogging';
import { makeLogger } from '../shared/logger';
import { Transaction, TransactionType } from '../shared/types';

const app = express();
app.use(express.json());
app.use(requestLoggingMiddleware('transaction-service'));

const log = makeLogger('transaction-service');
const config = getConfig();
const USER_SERVICE_URL = `http://localhost:${config.userServicePort}`;
const NOTIFICATION_SERVICE_URL = `http://localhost:${config.notificationServicePort}`;

const transactionsByUser = new Map<string, Transaction[]>();
const ALLOWED_TYPES: TransactionType[] = ['transfer', 'deposit', 'withdrawal'];
const MAX_AMOUNT = 1_000_000;

async function userExists(userId: string): Promise<boolean> {
  try {
    const resp = await fetch(`${USER_SERVICE_URL}/internal/users/${encodeURIComponent(userId)}/exists`);
    if (!resp.ok) return false;
    const body = (await resp.json()) as { exists: boolean };
    return body.exists;
  } catch (err) {
    log.error('userExists check failed', err);
    return false;
  }
}

function isValidAmount(amount: unknown): amount is number {
  if (typeof amount !== 'number' || Number.isNaN(amount) || !Number.isFinite(amount)) return false;
  if (amount <= 0 || amount > MAX_AMOUNT) return false;
  // reject more than 2 decimal places (currency precision)
  return Math.round(amount * 100) === amount * 100;
}

app.post('/transactions', async (req, res) => {
  const { userId, amount, type, recipientId } = req.body ?? {};
  const details: Record<string, string> = {};

  if (typeof userId !== 'string' || userId.trim().length === 0) {
    details.userId = 'userId is required';
  }
  if (!isValidAmount(amount)) {
    details.amount = `amount must be a positive number up to ${MAX_AMOUNT} with at most 2 decimal places`;
  }
  if (typeof type !== 'string' || !ALLOWED_TYPES.includes(type as TransactionType)) {
    details.type = `type must be one of: ${ALLOWED_TYPES.join(', ')}`;
  }
  if (type === 'transfer' && (typeof recipientId !== 'string' || recipientId.trim().length === 0)) {
    details.recipientId = 'recipientId is required when type is "transfer"';
  }
  if (type === 'transfer' && typeof recipientId === 'string' && recipientId === userId) {
    details.recipientId = 'recipientId cannot be the same as userId';
  }
  if (Object.keys(details).length > 0) {
    return ApiErrors.validation(res, 'Transaction creation failed validation', details);
  }

  const senderExists = await userExists(userId);
  if (!senderExists) {
    return ApiErrors.notFound(res, `No user found with id "${userId}"`);
  }
  if (type === 'transfer') {
    const recipientExists = await userExists(recipientId);
    if (!recipientExists) {
      return ApiErrors.badRequest(res, `recipientId "${recipientId}" does not exist`);
    }
  }

  const transaction: Transaction = {
    id: uuidv4(),
    userId,
    amount,
    type,
    ...(type === 'transfer' ? { recipientId } : {}),
    status: 'completed',
    createdAt: new Date().toISOString(),
  };

  const existing = transactionsByUser.get(userId) ?? [];
  existing.push(transaction);
  transactionsByUser.set(userId, existing);

  // Fire-and-forget notification - a failure here must never fail the transaction.
  fetch(`${NOTIFICATION_SERVICE_URL}/notifications`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId,
      channel: 'email',
      message: `Your ${type} of $${amount.toFixed(2)} was processed successfully.`,
    }),
  }).catch((err) => log.warn('notification dispatch failed (non-fatal)', err));

  return res.status(201).json(transaction);
});

app.get('/transactions/:userId', async (req, res) => {
  const { userId } = req.params;
  const exists = await userExists(userId);
  if (!exists) {
    return ApiErrors.notFound(res, `No user found with id "${userId}"`);
  }
  return res.status(200).json(transactionsByUser.get(userId) ?? []);
});

app.get('/health', (_req, res) => res.status(200).json({ status: 'ok', service: 'transaction-service' }));

app.listen(config.transactionServicePort, () => {
  console.log(`[transaction-service] listening on port ${config.transactionServicePort} (env=${config.name})`);
});

export default app;
