/**
 * API Test Suite - Transaction Service (via API Gateway)
 * Covers: CRUD, data validation, and error scenarios for
 * POST /api/transactions and GET /api/transactions/:userId.
 * Authentication/authorization for these endpoints lives in auth.spec.ts.
 */
import { test } from '../../utils/helpers/fixtures';
import { expect } from '../../utils/assertions/customAssertions';
import { buildUserPayload } from '../../utils/factories/userFactory';
import {
  buildDepositPayload,
  buildTransferPayload,
  buildWithdrawalPayload,
  invalidTransactionPayloads,
} from '../../utils/factories/transactionFactory';

interface CreatedUser {
  id: string;
  apiToken: string;
}

async function registerUser(apiClient: import('../../utils/helpers/apiClient').ApiClient): Promise<CreatedUser> {
  const response = await apiClient.createUser(buildUserPayload());
  return response.body as CreatedUser;
}

test.describe('Transaction API - CRUD', () => {
  test('creates a deposit transaction @smoke @crud', async ({ apiClient }) => {
    const user = await registerUser(apiClient);

    const response = await apiClient.createTransaction(buildDepositPayload(user.id, { amount: 250 }), user.apiToken);

    expect(response).toHaveStatus(201);
    expect(response.body).toBeValidTransactionShape();
    expect(response.body).toMatchObject({ userId: user.id, type: 'deposit', amount: 250, status: 'completed' });
  });

  test('creates a withdrawal transaction @crud', async ({ apiClient }) => {
    const user = await registerUser(apiClient);

    const response = await apiClient.createTransaction(buildWithdrawalPayload(user.id), user.apiToken);

    expect(response).toHaveStatus(201);
    expect(response.body).toMatchObject({ type: 'withdrawal', status: 'completed' });
  });

  test('creates a transfer transaction to a valid recipient @smoke @crud', async ({ apiClient }) => {
    const sender = await registerUser(apiClient);
    const recipient = await registerUser(apiClient);

    const response = await apiClient.createTransaction(
      buildTransferPayload(sender.id, recipient.id, { amount: 42.5 }),
      sender.apiToken,
    );

    expect(response).toHaveStatus(201);
    expect(response.body).toMatchObject({ type: 'transfer', recipientId: recipient.id, amount: 42.5 });
  });

  test('lists all transactions created for a user, newest included @smoke @crud', async ({ apiClient }) => {
    const user = await registerUser(apiClient);
    await apiClient.createTransaction(buildDepositPayload(user.id, { amount: 10 }), user.apiToken);
    await apiClient.createTransaction(buildDepositPayload(user.id, { amount: 20 }), user.apiToken);

    const response = await apiClient.getTransactions(user.id, user.apiToken);

    expect(response).toHaveStatus(200);
    expect(Array.isArray(response.body)).toBe(true);
    const amounts = (response.body as Array<{ amount: number }>).map((t) => t.amount);
    expect(amounts).toEqual(expect.arrayContaining([10, 20]));
  });

  test('returns an empty array for a user with no transactions yet @crud @edge-case', async ({ apiClient }) => {
    const user = await registerUser(apiClient);

    const response = await apiClient.getTransactions(user.id, user.apiToken);

    expect(response).toHaveStatus(200);
    expect(response.body).toEqual([]);
  });
});

test.describe('Transaction API - data validation & error scenarios', () => {
  test('rejects a transaction for a userId that does not exist, using an admin token @validation @negative', async ({
    apiClient,
    adminToken,
  }) => {
    const payload = invalidTransactionPayloads('does-not-exist-123', 'ignored').unknownUserId;
    const response = await apiClient.createTransaction(payload, adminToken);
    expect(response).toHaveStatus(404);
  });

  test('rejects creating a transaction for a userId other than the token owner @negative @authz', async ({
    apiClient,
  }) => {
    const owner = await registerUser(apiClient);
    const someoneElse = await registerUser(apiClient);

    // owner's token, but the payload claims to transact on someoneElse's behalf
    const response = await apiClient.createTransaction(buildDepositPayload(someoneElse.id), owner.apiToken);

    expect(response).toHaveStatus(403);
    expect(response).toHaveApiErrorCode('FORBIDDEN');
  });

  test('rejects a zero amount @validation', async ({ apiClient }) => {
    const user = await registerUser(apiClient);
    const response = await apiClient.createTransaction(
      invalidTransactionPayloads(user.id, 'x').zeroAmount,
      user.apiToken,
    );
    expect(response).toHaveStatus(422);
    expect((response.body as { error: { details: Record<string, string> } }).error.details).toHaveProperty(
      'amount',
    );
  });

  test('rejects a negative amount @validation', async ({ apiClient }) => {
    const user = await registerUser(apiClient);
    const response = await apiClient.createTransaction(
      invalidTransactionPayloads(user.id, 'x').negativeAmount,
      user.apiToken,
    );
    expect(response).toHaveStatus(422);
  });

  test('rejects an amount with more than 2 decimal places @validation @edge-case', async ({ apiClient }) => {
    const user = await registerUser(apiClient);
    const response = await apiClient.createTransaction(
      invalidTransactionPayloads(user.id, 'x').tooManyDecimals,
      user.apiToken,
    );
    expect(response).toHaveStatus(422);
  });

  test('rejects an unsupported transaction type @validation', async ({ apiClient }) => {
    const user = await registerUser(apiClient);
    const response = await apiClient.createTransaction(
      invalidTransactionPayloads(user.id, 'x').invalidType,
      user.apiToken,
    );
    expect(response).toHaveStatus(422);
    expect((response.body as { error: { details: Record<string, string> } }).error.details).toHaveProperty('type');
  });

  test('rejects a transfer missing recipientId @validation', async ({ apiClient }) => {
    const user = await registerUser(apiClient);
    const response = await apiClient.createTransaction(
      invalidTransactionPayloads(user.id, 'x').transferMissingRecipient,
      user.apiToken,
    );
    expect(response).toHaveStatus(422);
    expect((response.body as { error: { details: Record<string, string> } }).error.details).toHaveProperty(
      'recipientId',
    );
  });

  test('rejects a transfer where recipientId equals userId @validation @edge-case', async ({ apiClient }) => {
    const user = await registerUser(apiClient);
    const response = await apiClient.createTransaction(
      invalidTransactionPayloads(user.id, 'x').transferToSelf,
      user.apiToken,
    );
    expect(response).toHaveStatus(422);
  });

  test('rejects a transfer to a recipient that does not exist @validation @negative', async ({ apiClient }) => {
    const user = await registerUser(apiClient);
    const response = await apiClient.createTransaction(
      buildTransferPayload(user.id, 'does-not-exist-999'),
      user.apiToken,
    );
    expect(response).toHaveStatus(400);
    expect(response).toHaveApiErrorCode('BAD_REQUEST');
  });

  test('returns 404 when listing transactions for a non-existent userId @negative', async ({
    apiClient,
    adminToken,
  }) => {
    const response = await apiClient.getTransactions('11111111-1111-4111-8111-111111111111', adminToken);
    expect(response).toHaveStatus(404);
  });

  test('a failed validation does not create a transaction record @negative @data-integrity', async ({
    apiClient,
  }) => {
    const user = await registerUser(apiClient);
    const before = await apiClient.getTransactions(user.id, user.apiToken);
    const beforeCount = (before.body as unknown[]).length;

    await apiClient.createTransaction(invalidTransactionPayloads(user.id, 'x').negativeAmount, user.apiToken);

    const after = await apiClient.getTransactions(user.id, user.apiToken);
    expect((after.body as unknown[]).length).toBe(beforeCount);
  });
});
